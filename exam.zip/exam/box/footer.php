<!--Footer Starts Here-->
        <footer class="footer">
            <div class="wrapper">
                <p>
                    <a href="https://www.vssut.ac.in/" title="Veer Surendra Sai University Of Technology,Burla" target="_blank">Veer Surendra Sai University Of Technology,Burla</a> &copy; <?php echo date('Y'); ?>. All Rights Reserved.    
                    Powered by <a href="https://www.linkedin.com/in/saswat-behera-64a7b81b5/" title="Saswat Behera" target="_blank">Saswat Behera</a>.<br>
                    <?php echo date('');?>Mail To saswatbehera14@gmail.com For Any Quries.
                </p>
            </div>
        </footer>
        <!--Footer Ends Here-->
</html>