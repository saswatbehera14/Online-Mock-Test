<?php 
    define('SITEURL','http://localhost/exam/');
    define('LOCALHOST','localhost');
    define('USERNAME','root');
    define('PASSWORD','');
    define('DBNAME','quizapp');
?>